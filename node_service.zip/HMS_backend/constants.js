export const constants = {
  oprations: {
    get: "Get",
    add: "Add",
    put: "Put",
    delete: "Delete",
  },

  response_messages: {
    created: " created successfully!",
    registred: " registered successfull!",
    register_failed: " registration failed!",
    login_success: " login successfull!",
    get_success: " get successfull!",
    get_failed: " get failed!",
    login_failed: " login failed!",
    deleted: " deleted successfully!",
    delete_failed: " delete failed!",
    wrong: "Something went wrong!",
    failed: " create failed!",
    added_failed: " add failed!",
    invalidCred: "Invalid Cradentials!",
    isPresent: " already present!",
    updated: " Updated Successfully!",
    updated_failed: "Unable to Update ",
    required_field: " some fileds are empty",
  },
};
